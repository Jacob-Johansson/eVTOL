import socket
import json
import numpy as np
#from vpython import *
import copy


class eVtolConstructor:
    def __init__(self):
        pass
        """
        wingspan_minus_prop = 4
        prop_radi = 0.8

        body = ellipsoid(pos= vec(0,0,0),length=5,width=2,height=2,up=vec(0.2,0.9,0),color =basecolor,make_trail = True, retain = 50)
        #window = ellipsoid(pos= vec(0.1,0.1,0),length=4.8,width=2,height=1.8,up=vec(0.2,0.9,0),color=vec(0,0,0))
        wing1 = cylinder(pos=vec(-1.5,0.5,-wingspan_minus_prop/2),size=vec(wingspan_minus_prop,0.15,.7),axis=vec(0,0,1),color =basecolor)
        wing2 = cylinder(pos=vec(1.5,-0.5,-wingspan_minus_prop/2),size=vec(wingspan_minus_prop,0.15,.7),axis=vec(0,0,1),color =basecolor)

        tripath = [ vec(-1.5,0.25,-wingspan_minus_prop/2-prop_radi), vec(-1.5,0.75,-wingspan_minus_prop/2-prop_radi)]
        propc1 = extrusion(path=tripath,shape=shapes.circle(radius = prop_radi+.1, thickness= 0.1),color =basecolor)
        #prop1 = extrusion(path=[tripath[0]+vec(0,0.2,0),tripath[1]-vec(0,0.2,0)],shape=shapes.circle(radius = prop_radi+.1),color = color.gray(0.7), opacity = 0.3)

        tripath = [ vec(-1.5,0.25,wingspan_minus_prop/2+prop_radi), vec(-1.5,0.75,wingspan_minus_prop/2+prop_radi)]
        propc2 =extrusion(path=tripath,shape=shapes.circle(radius = prop_radi+.1, thickness= 0.1),color =basecolor)
        #prop2 = extrusion(path=[tripath[0]+vec(0,0.2,0),tripath[1]-vec(0,0.2,0)],shape=shapes.circle(radius = prop_radi+.1),color = color.gray(0.7), opacity = 0.3)

        tripath = [ vec(1.5,0.25-1,-wingspan_minus_prop/2-prop_radi), vec(1.5,0.75-1,-wingspan_minus_prop/2-prop_radi)]
        propc3 =extrusion(path=tripath,shape=shapes.circle(radius = prop_radi+.1, thickness= 0.1),color =basecolor)
        #prop3 = extrusion(path=[tripath[0]+vec(0,0.2,0),tripath[1]-vec(0,0.2,0)],shape=shapes.circle(radius = prop_radi+.1),color = color.gray(0.7), opacity = 0.3)

        tripath = [ vec(1.5,0.25-1,wingspan_minus_prop/2+prop_radi), vec(1.5,0.75-1,wingspan_minus_prop/2+prop_radi)]
        propc4 =extrusion(path=tripath,shape=shapes.circle(radius = prop_radi+.1, thickness= 0.1),color =basecolor)
        #prop4 = extrusion(path=[tripath[0]+vec(0,0.2,0),tripath[1]-vec(0,0.2,0)],shape=shapes.circle(radius = prop_radi+.1),color = color.gray(0.7), opacity = 0.3)
        
        self.obj = compound([body,wing1,wing2,propc1,propc2,propc3,propc4])#],prop1,prop2,prop3,prop4])
        self.obj.rotate(pi/2,axis = vec(1,0,0))
        self.base_size = copy.deepcopy(self.obj.size)
        """

    def scale(self,factor = 1):
        pass#self.obj.size = vec(self.base_size * factor)
    
        


# listen to UDP messages TO this adress
UDP_IP = "192.168.137.1"
UDP_PORT = 5005

#setup socket to listen 
sock = socket.socket(socket.AF_INET, # Internet
                     socket.SOCK_DGRAM) # UDP
sock.bind((UDP_IP, UDP_PORT))
sock.setblocking(1)	

firstmsgparsed = False

#log all recieved data?
logging = True

while True:

    data, addr = sock.recvfrom(1024) # buffer size is 1024 bytes
    print("received message: %s" % data)
    
    # some data was received! Clean up and split to separate vars
    datastring = str(data).replace("b\'","").replace("\\n\'","")
    datavars = str(datastring).split(";")
    if logging:
        with open('logfile.txt','+a') as f:
            f.write("\n"+(datastring))    #write data to new line 
    if len(datavars)>2:
        #f.write(data)    #write data to new line 
        if not firstmsgparsed:
            # if first iteration, create canvas and initialize plot

            #Parse individual beacon positions:
            b1pos = json.loads(datavars[5].replace('(','[').replace(')',']'))
            b2pos = json.loads(datavars[6].replace('(','[').replace(')',']'))
            b3pos = json.loads(datavars[7].replace('(','[').replace(')',']'))
            b4pos = json.loads(datavars[8].replace('(','[').replace(')',']'))
            b5pos = json.loads(datavars[9].replace('(','[').replace(')',']'))
            b6pos = json.loads(datavars[10].replace('(','[').replace(')',']'))
            bp = [b1pos,b2pos,b3pos,b4pos,b5pos,b6pos]

            #create canvas for polot
            #scene = canvas(width=2000, height=1700, center=vector(2,3,0),forward = vec(0,1,0.5), range=10, background=color.white)
            #scene.range=5

            #plot one sphere for each beacon in bp
            #for bc in bp:
            #    box(pos=vec(bc[0],bc[1],bc[2]), size=vec(0.2,0.2,0.2),color =vec(1,0,1))
            
            #plot a simple grid at Z = 0
            #gridsize_x = round(max([x[0] for x in bp]))
            #gridsize_y = round(max([y[1] for y in bp]))
            """
            for i in np.arange(0,gridsize_y,0.5):
                cylinder(pos = vec(0,i,0), length = gridsize_x-0.5, axis = vec(1,0,0),radius = 0.01)
            for i in np.arange(0,gridsize_x,0.5):      
                cylinder(pos = vec(i,0,0), length = gridsize_y-0.5, axis = vec(0,1,0),radius = 0.01)
                        
            scene.camera.pos = vec(gridsize_x,gridsize_y/2,20)
            scene.camera.axis = vec(0,0,-20)
            scene.camera.rotate(pi/2,vec(0,0,1))
            #parse calculated tag positions
            msg_Xpos = json.loads(datavars[2])
            msg_Ypos = json.loads(datavars[3])        
            #for some reason Z is nan sometimes. 
            if not isnan(float(datavars[4])):
                msg_Zpos = json.loads(datavars[4])
            
            #plot a sphere at the position of the drone tag. Save it as dronepoint for later
            dronepoint=eVtolConstructor(vec(1,0.5,0.5))#
            drone_trail = sphere(pos=vec(msg_Xpos,msg_Ypos,msg_Zpos), size=vec(0.05,0.05,0.05),color =vec(0,1,1), make_trail= True, retain = 50  )    
            dronepoint.scale(0.2)
            """
            firstmsgparsed = True

        # at each subsequent iteration:
        #statuscodes are not really used 
        msg_statuscode1 = json.loads(datavars[0])
        msg_statuscode2 = json.loads(datavars[1])
        
        # parse new tag coordinates
        #old_x = msg_Xpos
        #old_y = msg_Ypos
        #old_z = msg_Zpos
        #old = [msg_Xpos,msg_Ypos,msg_Zpos]

        #msg_Xpos = json.loads(datavars[2])
        #msg_Ypos = json.loads(datavars[3])
        #if not isnan(float(datavars[4])):
        #    msg_Zpos = json.loads(datavars[4])
        #new = [msg_Xpos,msg_Ypos,msg_Zpos]
        # set the sphere position to the new tag coordinates.
        #if max([abs(n-o) for n,o in zip(new, old)])<2:
        #    dronepoint.obj.pos=vec(msg_Xpos,msg_Ypos,msg_Zpos)
        #    drone_trail.pos=vec(msg_Xpos,msg_Ypos,msg_Zpos)


