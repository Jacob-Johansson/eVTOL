
#include <deca_device_api.h>
#include <deca_regs.h>
#include <deca_spi.h>
#include <port.h>
#include <shared_defines.h>
#include <shared_functions.h>
#include <config_options.h>
#include <inttypes.h>

extern void test_run_info(unsigned char *data);

/* Example application name */
#define APP_NAME "SS TWR INIT v1.0"

/* Default communication configuration. We use default non-STS DW mode. */
static dwt_config_t config = {
        5,               /* Channel number. */
        DWT_PLEN_128,    /* Preamble length. Used in TX only. */
        DWT_PAC8,        /* Preamble acquisition chunk size. Used in RX only. */
        9,               /* TX preamble code. Used in TX only. */
        9,               /* RX preamble code. Used in RX only. */
        1,               /* 0 to use standard 8 symbol SFD, 1 to use non-standard 8 symbol, 2 for non-standard 16 symbol SFD and 3 for 4z 8 symbol SDF type */
        DWT_BR_6M8,      /* Data rate. */
        DWT_PHRMODE_STD, /* PHY header mode. */
        DWT_PHRRATE_STD, /* PHY header rate. */
        (129 + 8 - 8),   /* SFD timeout (preamble length + 1 + SFD length - PAC size). Used in RX only. */
        DWT_STS_MODE_OFF, /* STS disabled */
        DWT_STS_LEN_64,/* STS length see allowed values in Enum dwt_sts_lengths_e */
        DWT_PDOA_M0      /* PDOA mode off */
};

/* Default antenna delay values for 64 MHz PRF. See NOTE 2 below. */
#define TX_ANT_DLY 16385
#define RX_ANT_DLY 16385
//init some arrays for data
uint32_t rx_times_latest[] = {0,0,0,0,0,0};
uint32_t rx_times_raw[] = {0,0,0,0,0,0};
double d_rx_times_latest[] = {0,0,0,0,0,0};
double ddist_beacons[] = {0,0,0,0,0,0};
double ddist_beacons_mean[] = {0,0,0,0,0,0};
double ddist_beacon2_hist[] = {0,0,0,0,0,0,0,0,0,0};
double ddist_beacon3_hist[] = {0,0,0,0,0,0,0,0,0,0};
double ddist_beacon4_hist[] = {0,0,0,0,0,0,0,0,0,0};
double ddist_beacon5_hist[] = {0,0,0,0,0,0,0,0,0,0};
double ddist_beacon6_hist[] = {0,0,0,0,0,0,0,0,0,0};
int hist_index = 0;

static double d_clock[] ={0,0,0,0,0,0};
static uint32_t delays[] = {0,0,0,0,0};

/* Frames used in the ranging process.*/
static uint8_t rx_pos_init_msg[] = {0x41, 0x88, 0, 0xCA, 0xDE, 0,0,0,0, 0xE0, 0, 0};
static uint8_t rx_pos_slave_msg[] = {0x41, 0x88, 0, 0xCA, 0xDE, 0,0,0,0, 0xE1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

/* Length of the common part of the message  */
#define ALL_MSG_COMMON_LEN 4
/* Index to access some of the fields in the frames involved in the process. */
#define ALL_MSG_SN_IDX 2 //sequence number
#define ALL_MSG_SOURCE_IDX 5 //source of a data frame
#define ALL_MSG_TARGET_IDX 7 //target of a data frame
#define ALL_MSG_FN_CODE 9    //function code (NOT IMPLEMENTED. But probably should be...)
#define RESP_MSG_POLL_RX_TS_IDX 10 //slave message delay time

/* Frame sequence number, incremented after each transmission. */
static uint8_t frame_seq_nb = 0;

/* Buffer to store received response message.
 * Its size is adjusted to longest frame that this example code is supposed to handle. */
#define RX_BUF_LEN 20
static uint8_t rx_buffer[RX_BUF_LEN];

/* Hold copy of status register state here for reference so that it can be examined at a debug breakpoint. */
static uint32_t status_reg = 0;

/* Receive response timeout. See NOTE 5 below. */
#define RESP_RX_TIMEOUT_UUS 4000

/* Hold copies of computed time of flight and distance here for reference so that it can be examined at a debug breakpoint. */
static double d_tof;
static double d_distance;
static int curr_snr = 0;
static int rec_valid_frames = 0;


/* Values for the PG_DELAY and TX_POWER registers reflect the bandwidth and power of the spectrum at the current
 * temperature. These values can be calibrated prior to taking reference measurements. See NOTE 2 below. */
extern dwt_txconfig_t txconfig_options;

/*! ------------------------------------------------------------------------------------------------------------------
 * @fn main()
 *
 * @brief Application entry point.
 *
 * @param  none
 *
 * @return none
 */
int drone_tag_6(void)
{
    init_uart();
    /* Display application name on LCD. */
    test_run_info((unsigned char *)APP_NAME);

    /* Configure SPI rate, DW3000 supports up to 38 MHz */
    port_set_dw_ic_spi_fastrate();

    /* Reset and initialize DW chip. */
    reset_DWIC(); /* Target specific drive of RSTn line into DW3000 low for a period. */

    Sleep(2); // Time needed for DW3000 to start up (transition from INIT_RC to IDLE_RC, or could wait for SPIRDY event)

    while (!dwt_checkidlerc()) /* Need to make sure DW IC is in IDLE_RC before proceeding */
    { };
    if (dwt_initialise(DWT_DW_INIT) == DWT_ERROR)
    {
        test_run_info((unsigned char *)"INIT FAILED     ");
        while (1)
        { };
    }

    /* Enabling LEDs here for debug so that for each TX the D1 LED will flash on DW3000 red eval-shield boards. */
    dwt_setleds(DWT_LEDS_ENABLE | DWT_LEDS_INIT_BLINK) ;

    /* Configure DW IC. See NOTE 13 below. */
    if(dwt_configure(&config)) /* if the dwt_configure returns DWT_ERROR either the PLL or RX calibration has failed the host should reset the device */
    {
        test_run_info((unsigned char *)"CONFIG FAILED     ");
        while (1)
        { };
    }

    /* Configure the TX spectrum parameters (power, PG delay and PG count) */
    dwt_configuretxrf(&txconfig_options);

    /* Apply default antenna delay value. See NOTE 2 below. */
    dwt_setrxantennadelay(RX_ANT_DLY);
    dwt_settxantennadelay(TX_ANT_DLY);

    /* Next can enable TX/RX states output on GPIOs 5 and 6 to help debug, and also TX/RX LEDs
     * Note, in real low power applications the LEDs should not be used. */
    dwt_setlnapamode(DWT_LNA_ENABLE | DWT_PA_ENABLE);

    /* Loop forever listening to beacon master or slave exchanges. */
    while (1)
    {
        dwt_setpreambledetecttimeout(0);
        /* Clear reception timeout*/
        dwt_setrxtimeout(0);

        /* Activate reception immediately. */
        dwt_rxenable(DWT_START_RX_IMMEDIATE);
        /* We assume that the transmission is achieved correctly, poll for reception of a frame or error/timeout. See NOTE 8 below. */
        while (!((status_reg = dwt_read32bitreg(SYS_STATUS_ID)) & (SYS_STATUS_RXFCG_BIT_MASK | SYS_STATUS_ALL_RX_TO | SYS_STATUS_ALL_RX_ERR)))
        { };

        /* Increment frame sequence number after transmission of the poll message (modulo 256). */
        frame_seq_nb++;

        if (status_reg & SYS_STATUS_RXFCG_BIT_MASK)
        {
            uint32_t frame_len;

            /* Clear good RX frame event in the DW IC status register. */
            dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_RXFCG_BIT_MASK);

            /* A frame has been received, read it into the local buffer. */
            frame_len = dwt_read32bitreg(RX_FINFO_ID) & RXFLEN_MASK;
            if (frame_len <= sizeof(rx_buffer))
            {
                dwt_readrxdata(rx_buffer, frame_len, 0);
                int snr;

                 /* As the sequence number field of the frame is not relevant, it is cleared to simplify the validation of the frame. */
                snr = rx_buffer[ALL_MSG_SN_IDX];
                rx_buffer[ALL_MSG_SN_IDX] = 0; //ignore serial number while comparing

                //Check if message was master (init) message or slave message. Ignore otherwise
                if ((memcmp(rx_buffer, rx_pos_slave_msg, ALL_MSG_COMMON_LEN) == 0)||
                    (memcmp(rx_buffer, rx_pos_init_msg, ALL_MSG_COMMON_LEN) == 0))
                {

                    uint32_t poll_tx_ts, resp_rx_ts, resp_tx_ts;
                    uint32_t beacon_delay_32;
                    float clockOffsetRatio; //estimated clock offset ratio between sender and receiver

                    /* Retrieve beacon message reception timestamp */
                    resp_rx_ts = dwt_readrxtimestamplo32();
                    clockOffsetRatio = ((float)dwt_readclockoffset()) / (uint32_t)(1<<26);
                    /* Get delay time embedded in slave message. */
                    resp_msg_get_ts(&rx_buffer[RESP_MSG_POLL_RX_TS_IDX], &beacon_delay_32);

                    //depending on who sent the message (which beacon):
                    switch ((int)rx_buffer[ALL_MSG_SOURCE_IDX])
                        {
                          case 1: //Master beacon. New positioning sequence initiated, clear previous rx times
                            rx_times_latest[1] = 0;
                            rx_times_latest[2] = 0;
                            rx_times_latest[3] = 0;
                            rx_times_latest[4] = 0;
                            rx_times_latest[5] = 0;
                            rx_times_latest[0] = resp_rx_ts; //Save master signal RX time
                            rx_times_raw[0] = resp_rx_ts; //unsure what this is :D
                            d_clock[0] = (double)clockOffsetRatio; //save the estimated clock offset ratio for analysis
                            curr_snr = snr; //save the current sequence serial number
                            rec_valid_frames = 1; //one ok signal received!                            
                            break;
                          case 2:
                          //Beacon number two! Check i serial number agrees with current (=last master msg)
                          if (curr_snr==snr)
                            {
                              rx_times_latest[1] = resp_rx_ts-beacon_delay_32*(1-clockOffsetRatio); //reception time is rx_time minus beacon delay (adjusted for clock drift)
                              delays[1] = beacon_delay_32; // saved for analysis
                              rx_times_raw[1] = resp_rx_ts; // saved for analysis
                              d_rx_times_latest[1] = rx_times_latest[0]-(resp_rx_ts-(double)beacon_delay_32*(1-clockOffsetRatio));//deltaRx is rx of master message minus current (beacon 2) rx time
                              d_clock[1] = (double)clockOffsetRatio; // saved clock drift for analysis
                              d_tof = (double)d_rx_times_latest[1] * (double)DWT_TIME_UNITS; // raw time difference in DWTU
                              ddist_beacons[1] = d_tof * SPEED_OF_LIGHT; //delta-distance between beacon 2 and master, m
                              ddist_beacon2_hist[hist_index] = ddist_beacons[1]; // save a couple for averaging
                              rec_valid_frames++; //increment number of valid beacon msgs
                            }

                            break;
                          case 3: //Se above
                          if (curr_snr==snr)
                            {
                              rx_times_latest[2] = resp_rx_ts-beacon_delay_32*(1-clockOffsetRatio);
                              delays[2] = beacon_delay_32;
                              rx_times_raw[2] = resp_rx_ts;
                              d_rx_times_latest[2] = rx_times_latest[0]-(resp_rx_ts-(double)beacon_delay_32*(1-clockOffsetRatio));//(rx_times_latest[2]-rx_times_latest[0]);
                              d_clock[2] = (double)clockOffsetRatio;
                              d_tof = (double)d_rx_times_latest[2] * (double)DWT_TIME_UNITS;
                              ddist_beacons[2] = d_tof * SPEED_OF_LIGHT;
                              ddist_beacon3_hist[hist_index] = ddist_beacons[2];
                              rec_valid_frames++;
                            }

                            break;

                          case 4: //Se above
                          if (curr_snr==snr)
                            {
                              rx_times_latest[3] = resp_rx_ts-beacon_delay_32*(1-clockOffsetRatio);
                              delays[3] = beacon_delay_32;
                              rx_times_raw[3] = resp_rx_ts;
                              d_rx_times_latest[3] = rx_times_latest[0]-(resp_rx_ts-(double)beacon_delay_32*(1-clockOffsetRatio));//(rx_times_latest[2]-rx_times_latest[0]);
                              d_clock[3] = (double)clockOffsetRatio;
                              d_tof = (double)d_rx_times_latest[3] * (double)DWT_TIME_UNITS;
                              ddist_beacons[3] = d_tof * SPEED_OF_LIGHT;
                              ddist_beacon4_hist[hist_index] = ddist_beacons[3];
                              rec_valid_frames++;
                            }

                            break;

                          case 5: //Se above
                          if (curr_snr==snr)
                            {
                              rx_times_latest[4] = resp_rx_ts-beacon_delay_32*(1-clockOffsetRatio);
                              delays[4] = beacon_delay_32;
                              rx_times_raw[4] = resp_rx_ts;
                              d_rx_times_latest[4] = rx_times_latest[0]-(resp_rx_ts-(double)beacon_delay_32*(1-clockOffsetRatio));//(rx_times_latest[2]-rx_times_latest[0]);
                              d_clock[4] = (double)clockOffsetRatio;
                              d_tof = (double)d_rx_times_latest[4] * (double)DWT_TIME_UNITS;
                              ddist_beacons[4] = d_tof * SPEED_OF_LIGHT;
                              ddist_beacon5_hist[hist_index] = ddist_beacons[4];
                              rec_valid_frames++;
                            }

                            break;

                          case 6:
                            if (curr_snr==snr && rec_valid_frames == 5)
                            // Last message in sequence!
                            {

                                //Se above
                                rx_times_latest[5] = resp_rx_ts-beacon_delay_32*(1*clockOffsetRatio);
                                delays[5] = beacon_delay_32;
                                rx_times_raw[5] = resp_rx_ts;
                                d_rx_times_latest[5] = rx_times_latest[0]-(resp_rx_ts-(double)beacon_delay_32*(1-clockOffsetRatio));//(rx_times_latest[3]-rx_times_latest[0]);
                                d_clock[5] = (double)clockOffsetRatio;
                                d_tof = (double)d_rx_times_latest[5] * (double)DWT_TIME_UNITS;
                                ddist_beacons[5] = d_tof * SPEED_OF_LIGHT;
                                ddist_beacon6_hist[hist_index] = ddist_beacons[5];
                                
                                //increase circle memory index
                                hist_index++;                            
                                if (hist_index >= 5)
                                {
                                  hist_index = 0;
                                }
                                ddist_beacons_mean[1] = 0;
                                ddist_beacons_mean[2] = 0;
                                ddist_beacons_mean[3] = 0;
                                ddist_beacons_mean[4] = 0;
                                ddist_beacons_mean[5] = 0;


                                //Average all distances over 5 latest values
                                int avg_i;
                                for (avg_i = 0; avg_i <5; ++avg_i)
                                {
                                  ddist_beacons_mean[1] = ddist_beacons_mean[1] + ddist_beacon2_hist[avg_i];
                                  ddist_beacons_mean[2] = ddist_beacons_mean[2] + ddist_beacon3_hist[avg_i];
                                  ddist_beacons_mean[3] = ddist_beacons_mean[3] + ddist_beacon4_hist[avg_i];
                                  ddist_beacons_mean[4] = ddist_beacons_mean[4] + ddist_beacon5_hist[avg_i];
                                  ddist_beacons_mean[5] = ddist_beacons_mean[5] + ddist_beacon6_hist[avg_i];
                                }
                                ddist_beacons_mean[1] = ddist_beacons_mean[1]/5;
                                ddist_beacons_mean[2] = ddist_beacons_mean[2]/5;
                                ddist_beacons_mean[3] = ddist_beacons_mean[3]/5;
                                ddist_beacons_mean[4] = ddist_beacons_mean[4]/5;
                                ddist_beacons_mean[5] = ddist_beacons_mean[5]/5;

                                //Pack up a string and chuck out on the UART pins. String is "Status;[BeaconA_XYZ];[BeaconB_XYZ]....,[dB_A,dC_A,dD_A....]\n"
                                //(Status is always = 1, havent implemented yet)
                                char strtosend[128];
                                sprintf(strtosend,"1;[0.14,0.05,0];[1.95,14.35,0];[9.89,13.88,0];[10.35,0.11,0];[0.05,6.96,0];[10.36,7.91,1.05];[%f,%f,%f,%f,%f]\n",ddist_beacons_mean[1],ddist_beacons_mean[2],ddist_beacons_mean[3],ddist_beacons_mean[4],ddist_beacons_mean[5]);
                                send_uart(strtosend); //Send!
                            }
                            rec_valid_frames = 0;
                            break;
                        }

                }
                else 
                {
                int dummy = 1;
                }            
            }
        }
        else
        {
            /* Clear RX error/timeout events in the DW IC status register. */          

            dwt_write32bitreg(SYS_STATUS_ID, SYS_STATUS_ALL_RX_TO | SYS_STATUS_ALL_RX_ERR);
        }
    }
}

//!!!!!!!!BELOW NOTES ARE FROM ORIGINAL EXAMPLE FILE; THEY ARE NOT APPLICABLE TO ABOVE CODE BUT MIGHT PROVIDE SOME CONTEXT!!!!!!!!!!!!!!
/*****************************************************************************************************************************************************
 * NOTES:
 *
 * 1. The single-sided two-way ranging scheme implemented here has to be considered carefully as the accuracy of the distance measured is highly
 *    sensitive to the clock offset error between the devices and the length of the response delay between frames. To achieve the best possible
 *    accuracy, this response delay must be kept as low as possible. In order to do so, 6.8 Mbps data rate is used in this example and the response
 *    delay between frames is defined as low as possible. The user is referred to User Manual for more details about the single-sided two-way ranging
 *    process.  NB:SEE ALSO NOTE 11.
 *
 *    Initiator: |Poll TX| ..... |Resp RX|
 *    Responder: |Poll RX| ..... |Resp TX|
 *                   ^|P RMARKER|                    - time of Poll TX/RX
 *                                   ^|R RMARKER|    - time of Resp TX/RX
 *
 *                       <--TDLY->                   - POLL_TX_TO_RESP_RX_DLY_UUS (RDLY-RLEN)
 *                               <-RLEN->            - RESP_RX_TIMEOUT_UUS   (length of response frame)
 *                    <----RDLY------>               - POLL_RX_TO_RESP_TX_DLY_UUS (depends on how quickly responder can turn around and reply)
 *
 *
 * 2. The sum of the values is the TX to RX antenna delay, this should be experimentally determined by a calibration process. Here we use a hard coded
 *    value (expected to be a little low so a positive error will be seen on the resultant distance estimate). For a real production application, each
 *    device should have its own antenna delay properly calibrated to get good precision when performing range measurements.
 * 3. The frames used here are Decawave specific ranging frames, complying with the IEEE 802.15.4 standard data frame encoding. The frames are the
 *    following:
 *     - a poll message sent by the initiator to trigger the ranging exchange.
 *     - a response message sent by the responder to complete the exchange and provide all information needed by the initiator to compute the
 *       time-of-flight (distance) estimate.
 *    The first 10 bytes of those frame are common and are composed of the following fields:
 *     - byte 0/1: frame control (0x8841 to indicate a data frame using 16-bit addressing).
 *     - byte 2: sequence number, incremented for each new frame.
 *     - byte 3/4: PAN ID (0xDECA).
 *     - byte 5/6: destination address, see NOTE 4 below.
 *     - byte 7/8: source address, see NOTE 4 below.
 *     - byte 9: function code (specific values to indicate which message it is in the ranging process).
 *    The remaining bytes are specific to each message as follows:
 *    Poll message:
 *     - no more data
 *    Response message:
 *     - byte 10 -> 13: poll message reception timestamp.
 *     - byte 14 -> 17: response message transmission timestamp.
 *    All messages end with a 2-byte checksum automatically set by DW IC.
 * 4. Source and destination addresses are hard coded constants in this example to keep it simple but for a real product every device should have a
 *    unique ID. Here, 16-bit addressing is used to keep the messages as short as possible but, in an actual application, this should be done only
 *    after an exchange of specific messages used to define those short addresses for each device participating to the ranging exchange.
 * 5. This timeout is for complete reception of a frame, i.e. timeout duration must take into account the length of the expected frame. Here the value
 *    is arbitrary but chosen large enough to make sure that there is enough time to receive the complete response frame sent by the responder at the
 *    6.8M data rate used (around 200 µs).
 * 6. In a real application, for optimum performance within regulatory limits, it may be necessary to set TX pulse bandwidth and TX power, (using
 *    the dwt_configuretxrf API call) to per device calibrated values saved in the target system or the DW IC OTP memory.
 * 7. dwt_writetxdata() takes the full size of the message as a parameter but only copies (size - 2) bytes as the check-sum at the end of the frame is
 *    automatically appended by the DW IC. This means that our variable could be two bytes shorter without losing any data (but the sizeof would not
 *    work anymore then as we would still have to indicate the full length of the frame to dwt_writetxdata()).
 * 8. We use polled mode of operation here to keep the example as simple as possible but all status events can be used to generate interrupts. Please
 *    refer to DW IC User Manual for more details on "interrupts". It is also to be noted that STATUS register is 5 bytes long but, as the event we
 *    use are all in the first bytes of the register, we can use the simple dwt_read32bitreg() API call to access it instead of reading the whole 5
 *    bytes.
 * 9. The high order byte of each 40-bit time-stamps is discarded here. This is acceptable as, on each device, those time-stamps are not separated by
 *    more than 2**32 device time units (which is around 67 ms) which means that the calculation of the round-trip delays can be handled by a 32-bit
 *    subtraction.
 * 10. The user is referred to DecaRanging ARM application (distributed with EVK1000 product) for additional practical example of usage, and to the
 *     DW IC API Guide for more details on the DW IC driver functions.
 * 11. The use of the clock offset value to correct the TOF calculation, significantly improves the result of the SS-TWR where the remote
 *     responder unit's clock is a number of PPM offset from the local initiator unit's clock.
 *     As stated in NOTE 2 a fixed offset in range will be seen unless the antenna delay is calibrated and set correctly.
 * 12. In this example, the DW IC is put into IDLE state after calling dwt_initialise(). This means that a fast SPI rate of up to 20 MHz can be used
 *     thereafter.
 * 13. Desired configuration by user may be different to the current programmed configuration. dwt_configure is called to set desired
 *     configuration.
 ****************************************************************************************************************************************************/
