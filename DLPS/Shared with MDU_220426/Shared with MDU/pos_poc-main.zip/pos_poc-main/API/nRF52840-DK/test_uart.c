
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include "app_uart.h"
#include "app_error.h"
#include "nrf_delay.h"
#include "nrf.h"
#include "bsp.h"
#include "nrf_uart.h"
#include <string.h>

#define UART_TX_BUFF_SIZE 128 // TX buffer size
#define UART_RX_BUFF_SIZE 128 // RX Buffer size


#define UART_HWFC APP_UART_FLOW_CONTROL_DISABLED

//void uart_put_array(uint32 input)

// A simple error handler for uart if something goes wrong...
void uart_err_handle(app_uart_evt_type_t * p)
{
  
}



int init_uart(void)
{
  uint32_t err_code; // a variable to hold the error value

  bsp_board_init(BSP_INIT_LEDS); // initialize leds


  const app_uart_comm_params_t com_params = // struct to hold the uart configurations
  {
    RX_PIN_NUMBER, 
    TX_PIN_NUMBER,
    RTS_PIN_NUMBER,
    CTS_PIN_NUMBER,
    UART_HWFC, // hardware flow control disabled
    false, // parity = none
    NRF_UART_BAUDRATE_115200 // set this baud rate for communication

  };

// pass all the values to this function to initialize the UART module
 APP_UART_FIFO_INIT(&com_params, UART_RX_BUFF_SIZE, UART_TX_BUFF_SIZE, uart_err_handle, APP_IRQ_PRIORITY_LOWEST, err_code);


  APP_ERROR_CHECK(err_code); // check if everything initialized correctly
}

void send_uart(char stringtosend[])
{
    int i;
    for (i=0;i<strlen(stringtosend);++i)
    {
      app_uart_put(stringtosend[i]);
    }
}


void send_testuart(void)
{
  while(true) //old test code
  {
    uint8_t cr; // create a variable to hold the UART char data
    nrf_delay_ms(100);
    //StatusInt;[B1PosX,B1PosY,B1PosZ];[B2PosX....];[B3...];[B4...];dDist[1-2,1-3,1-4]\n;
    char string[] = "1;[0,0,0];[14,0,0];[0,14,0];[14,14,10];[0.003,-1.996,2.967]\n";
    //sprintf("Kalle %d\n",iller);
    int i;
    for (i=0;i<strlen(string);++i)
    {
    app_uart_put(string[i]);
    }


    
    //while(app_uart_get(&cr) != NRF_SUCCESS); // wait here until it receives a char from pc
    app_uart_get(&cr);

    if(cr == 't') // check if the received char is t
    {
    bsp_board_leds_on(); // turn on all the leds
    printf("Leds Turned On!!\r\n"); // print out the state of leds
    }

    if(cr == 'k') // check if the received chart is k
    {
    bsp_board_leds_off(); // turn off all the leds
    printf("Leds Turned off!! \r\n"); // print out the state of leds

    }


    } // while loop closed


   
} // main function closed


/** @} */
